package bracathon.com.bracathon.program_operator;

public class DataPO {
    public static String user_id;
}
