package bracathon.com.bracathon.program_operator;

public class Data {
    public static String user_id;
}
