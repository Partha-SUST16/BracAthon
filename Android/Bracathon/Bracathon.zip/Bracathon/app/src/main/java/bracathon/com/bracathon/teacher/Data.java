package bracathon.com.bracathon.teacher;

public class Data {
    public static String school_id;
    public static String user_id;
    public static String attendence;
}
