package com.example.clarifai_facerecognition;

public class JsonActivity  {
}
