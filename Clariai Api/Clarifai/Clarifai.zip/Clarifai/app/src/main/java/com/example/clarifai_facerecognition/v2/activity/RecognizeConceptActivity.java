package com.example.clarifai_facerecognition.v2.activity;

import android.support.v7.widget.RecyclerView;

public class RecognizeConceptActivity {
    public static final int PICK_IMAGE = 100;
}
